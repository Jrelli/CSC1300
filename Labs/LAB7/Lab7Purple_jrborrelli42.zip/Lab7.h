/*
    File Name:          Lab7.h
    Creator Name:       Joey R. Borrelli
    Date Started:       10/19/2023
    Program Purpose:    header file with prototypes and imports
*/

#ifndef LAB7_H
#define LAB7_H

#include <iostream>
using namespace std;

void getData(string&, string&, int&, int&, string&, string&);
bool calculateResults(string, string, int, int, string, string);

#endif