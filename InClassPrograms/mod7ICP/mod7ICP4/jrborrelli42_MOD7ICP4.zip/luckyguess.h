#ifndef LUCKYGUESS_H
#define LUCKYGUESS_H

#include <iostream>
using namespace std;

void getUserData(string& name, string& favFood, int& favNum);
bool luckyGuess(int num);

#endif